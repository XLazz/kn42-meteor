(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var EJSON = Package.ejson.EJSON;

/* Package-scope variables */
var Gapi;

(function () {

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// packages/cscottnet:googleapis/googleapis.js                               //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
                                                                             //
var googleapis = Npm.require('googleapis');                                  // 1
var crypto = Npm.require('crypto');                                          // 2
                                                                             // 3
// meteor < 0.9.3 compatibility                                              // 4
var wrapAsync = (Meteor.wrapAsync || Meteor._wrapAsync).bind(Meteor);        // 5
                                                                             // 6
var globalAuth;                                                              // 7
                                                                             // 8
Gapi = {                                                                     // 9
  apis: googleapis,                                                          // 10
                                                                             // 11
  registerAuth: function(auth) { globalAuth = auth; },                       // 12
                                                                             // 13
  // Helper functions to execute a google api request.                       // 14
  // Execution is synchronous if callback is omitted                         // 15
  exec: wrapAsync(function(request, auth, callback) {                        // 16
    if (typeof(callback)==='undefined' && typeof(auth)==='function') {       // 17
      callback = auth; auth = undefined; // shift args over                  // 18
    }                                                                        // 19
    auth = auth || globalAuth;                                               // 20
    if (auth) { request = request.withAuthClient(auth); }                    // 21
    request.execute(callback);                                               // 22
  }),                                                                        // 23
                                                                             // 24
  // Helper function to execute google authorization, synchronously          // 25
  authorize: wrapAsync(function(auth, callback) {                            // 26
    auth.authorize(callback);                                                // 27
  }),                                                                        // 28
                                                                             // 29
  // Helper functions to encrypt/decrypt keys from Asset storage             // 30
                                                                             // 31
  // takes a string and a password string, returns an EJSON binary           // 32
  crypt: function(data, password) {                                          // 33
    password = new Buffer(password, 'utf8'); // encode string as utf8        // 34
    var encrypt = crypto.createCipher('aes256', password);                   // 35
    var output1 = encrypt.update(data, 'utf8', null);                        // 36
    var output2 = encrypt.final(null);                                       // 37
    var r = EJSON.newBinary(output1.length + output2.length);                // 38
    var i;                                                                   // 39
    for (i=0; i<output1.length; i++) { r[i] = output1[i]; }                  // 40
    for (i=0; i<output2.length; i++) { r[output1.length + i] = output2[i]; } // 41
    return r;                                                                // 42
  },                                                                         // 43
                                                                             // 44
  // takes an EJSON binary and a password string, returns a string.          // 45
  decrypt: function(data, password) {                                        // 46
    password = new Buffer(password, 'utf8'); // encode string as utf8        // 47
    var decrypt = crypto.createDecipher('aes256', password);                 // 48
    data = new Buffer(data); // convert EJSON binary to Buffer               // 49
    var output = decrypt.update(data, null, 'utf8');                         // 50
    output += decrypt.final('utf8');                                         // 51
    return output;                                                           // 52
  }                                                                          // 53
};                                                                           // 54
                                                                             // 55
///////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cscottnet:googleapis'] = {
  Gapi: Gapi
};

})();

//# sourceMappingURL=cscottnet_googleapis.js.map
