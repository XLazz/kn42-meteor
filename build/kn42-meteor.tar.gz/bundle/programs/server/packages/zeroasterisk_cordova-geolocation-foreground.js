(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zeroasterisk:cordova-geolocation-foreground'] = {};

})();

//# sourceMappingURL=zeroasterisk_cordova-geolocation-foreground.js.map
