(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var OAuth = Package.oauth.OAuth;
var Oauth = Package.oauth.Oauth;
var HTTP = Package.http.HTTP;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;

/* Package-scope variables */
var Foursquare;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/msamoylov:foursquare/foursquare_server.js                                                    //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
Foursquare = {};                                                                                         // 1
                                                                                                         // 2
OAuth.registerService('foursquare', 2, null, function(query) {                                           // 3
                                                                                                         // 4
    var accessToken = getAccessToken(query);                                                             // 5
    var identity = getIdentity(accessToken);                                                             // 6
                                                                                                         // 7
    return {                                                                                             // 8
        serviceData: {                                                                                   // 9
            id: identity.id,                                                                             // 10
            accessToken: OAuth.sealSecret(accessToken),                                                  // 11
            email: identity.contact.email                                                                // 12
        },                                                                                               // 13
        options: {                                                                                       // 14
            profile: {                                                                                   // 15
                firstName: identity.firstName,                                                           // 16
                lastName: identity.lastName                                                              // 17
            }                                                                                            // 18
        }                                                                                                // 19
    };                                                                                                   // 20
});                                                                                                      // 21
                                                                                                         // 22
var getAccessToken = function (query) {                                                                  // 23
    var config = ServiceConfiguration.configurations.findOne({service: 'foursquare'});                   // 24
    if (!config)                                                                                         // 25
        throw new ServiceConfiguration.ConfigError();                                                    // 26
                                                                                                         // 27
    var response;                                                                                        // 28
    try {                                                                                                // 29
        response = HTTP.post(                                                                            // 30
            "https://foursquare.com/oauth2/access_token", {                                              // 31
                headers: {                                                                               // 32
                    Accept: 'application/json'                                                           // 33
                },                                                                                       // 34
                params: {                                                                                // 35
                    client_id: config.clientId,                                                          // 36
                    client_secret: OAuth.openSecret(config.secret),                                      // 37
                    grant_type: 'authorization_code',                                                    // 38
                    redirect_uri: Meteor.absoluteUrl('_oauth/foursquare'),                               // 39
                    code: query.code,                                                                    // 40
                    state: query.state                                                                   // 41
                }                                                                                        // 42
            });                                                                                          // 43
    } catch (err) {                                                                                      // 44
        throw _.extend(new Error("Failed to complete OAuth handshake with Foursquare. " + err.message),  // 45
            {response: err.response});                                                                   // 46
    }                                                                                                    // 47
    if (response.data.errorType) { // if the http response was a json object with an errorType attribute // 48
        throw new Error("Failed to complete OAuth handshake with Foursquare. " + response.data);         // 49
    } else {                                                                                             // 50
        return response.data.access_token;                                                               // 51
    }                                                                                                    // 52
};                                                                                                       // 53
                                                                                                         // 54
var getIdentity = function (accessToken) {                                                               // 55
    try {                                                                                                // 56
        return HTTP.get(                                                                                 // 57
            "https://api.foursquare.com/v2/users/self", {                                                // 58
                params: {                                                                                // 59
                    oauth_token: accessToken,                                                            // 60
                    v: '20141106'                                                                        // 61
                }                                                                                        // 62
            }).data.response.user;                                                                       // 63
    } catch (err) {                                                                                      // 64
        throw _.extend(new Error("Failed to fetch identity from Foursquare. " + err.message),            // 65
            {response: err.response});                                                                   // 66
    }                                                                                                    // 67
};                                                                                                       // 68
                                                                                                         // 69
                                                                                                         // 70
Foursquare.retrieveCredential = function(credentialToken, credentialSecret) {                            // 71
    return OAuth.retrieveCredential(credentialToken, credentialSecret);                                  // 72
};                                                                                                       // 73
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['msamoylov:foursquare'] = {
  Foursquare: Foursquare
};

})();

//# sourceMappingURL=msamoylov_foursquare.js.map
