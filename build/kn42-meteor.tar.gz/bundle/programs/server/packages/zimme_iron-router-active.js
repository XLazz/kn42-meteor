(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var _s = Package['wizonesolutions:underscore-string']._s;
var Iron = Package['iron:core'].Iron;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zimme:iron-router-active'] = {};

})();

//# sourceMappingURL=zimme_iron-router-active.js.map
