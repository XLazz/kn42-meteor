(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;

/* Package-scope variables */
var DocumentRefCounter, Publication, Subscription, debugLog;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/reywood:publish-composite/lib/doc_ref_counter.js                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
DocumentRefCounter = function(observer) {                                                                           // 1
    this.heap = {};                                                                                                 // 2
    this.observer = observer;                                                                                       // 3
};                                                                                                                  // 4
                                                                                                                    // 5
DocumentRefCounter.prototype.increment = function(collectionName, docId) {                                          // 6
    var key = collectionName + ":" + docId.valueOf();                                                               // 7
    if (!this.heap[key]) {                                                                                          // 8
        this.heap[key] = 0;                                                                                         // 9
    }                                                                                                               // 10
    this.heap[key]++;                                                                                               // 11
};                                                                                                                  // 12
                                                                                                                    // 13
DocumentRefCounter.prototype.decrement = function(collectionName, docId) {                                          // 14
    var key = collectionName + ":" + docId.valueOf();                                                               // 15
    if (this.heap[key]) {                                                                                           // 16
        this.heap[key]--;                                                                                           // 17
                                                                                                                    // 18
        this.observer.onChange(collectionName, docId, this.heap[key]);                                              // 19
    }                                                                                                               // 20
};                                                                                                                  // 21
                                                                                                                    // 22
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/reywood:publish-composite/lib/publication.js                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Publication = function(subscription, options, args) {                                                               // 1
    this.subscription = subscription;                                                                               // 2
    this.options = options;                                                                                         // 3
    this.args = args || [];                                                                                         // 4
    this.childrenOptions = options.children || [];                                                                  // 5
    this.publishedDocs = new PublishedDocumentList();                                                               // 6
    this.collectionName = options.collectionName;                                                                   // 7
};                                                                                                                  // 8
                                                                                                                    // 9
Publication.prototype.publish = function() {                                                                        // 10
    this.cursor = this._getCursor();                                                                                // 11
                                                                                                                    // 12
    if (!this.cursor) { return; }                                                                                   // 13
                                                                                                                    // 14
    var collectionName = this._getCollectionName();                                                                 // 15
    var self = this;                                                                                                // 16
                                                                                                                    // 17
    this.observeHandle = this.cursor.observe({                                                                      // 18
        added: function(doc) {                                                                                      // 19
            var alreadyPublished = self.publishedDocs.has(doc._id);                                                 // 20
                                                                                                                    // 21
            if (alreadyPublished) {                                                                                 // 22
                debugLog("Publication.observeHandle.added", collectionName + ":" + doc._id + " already published"); // 23
                self.subscription.changed(collectionName, doc._id, doc);                                            // 24
                self._republishChildrenOf(doc);                                                                     // 25
            } else {                                                                                                // 26
                self.publishedDocs.add(doc._id);                                                                    // 27
                self.subscription.added(collectionName, doc);                                                       // 28
                self._publishChildrenOf(doc);                                                                       // 29
            }                                                                                                       // 30
        },                                                                                                          // 31
        changed: function(newDoc) {                                                                                 // 32
            debugLog("Publication.observeHandle.changed", collectionName + ":" + newDoc._id);                       // 33
            self._republishChildrenOf(newDoc);                                                                      // 34
        },                                                                                                          // 35
        removed: function(doc) {                                                                                    // 36
            debugLog("Publication.observeHandle.removed", collectionName + ":" + doc._id);                          // 37
            self._removeDoc(collectionName, doc._id);                                                               // 38
        }                                                                                                           // 39
    });                                                                                                             // 40
                                                                                                                    // 41
    this.observeChangesHandle = this.cursor.observeChanges({                                                        // 42
        changed: function(id, fields) {                                                                             // 43
            debugLog("Publication.observeChangesHandle.changed", collectionName + ":" + id);                        // 44
            self.subscription.changed(collectionName, id, fields);                                                  // 45
        }                                                                                                           // 46
    });                                                                                                             // 47
};                                                                                                                  // 48
                                                                                                                    // 49
Publication.prototype.unpublish = function() {                                                                      // 50
    debugLog("Publication.unpublish", this._getCollectionName());                                                   // 51
    this._stopObservingCursor();                                                                                    // 52
    this._unpublishAllDocuments();                                                                                  // 53
};                                                                                                                  // 54
                                                                                                                    // 55
Publication.prototype._republish = function() {                                                                     // 56
    var collectionName = this._getCollectionName();                                                                 // 57
    var oldPublishedIds = this.publishedDocs.getIds();                                                              // 58
                                                                                                                    // 59
    debugLog("Publication._republish", "stop observing old cursor");                                                // 60
    this._stopObservingCursor();                                                                                    // 61
                                                                                                                    // 62
    debugLog("Publication._republish", "run .publish again");                                                       // 63
    this.publish();                                                                                                 // 64
                                                                                                                    // 65
    var newPublishedIds = this._getPublishedIds();                                                                  // 66
    var docsToRemove = _.difference(oldPublishedIds, newPublishedIds);                                              // 67
                                                                                                                    // 68
    debugLog("Publication._republish", "unpublish docs from old cursor");                                           // 69
    _.each(docsToRemove, function(docId) {                                                                          // 70
        this._removeDoc(collectionName, docId);                                                                     // 71
    }, this);                                                                                                       // 72
};                                                                                                                  // 73
                                                                                                                    // 74
Publication.prototype._getCursor = function() {                                                                     // 75
    return this.options.find.apply(this.subscription.meteorSub, this.args);                                         // 76
};                                                                                                                  // 77
                                                                                                                    // 78
Publication.prototype._getCollectionName = function() {                                                             // 79
    return this.collectionName || (this.cursor && this.cursor._getCollectionName());                                // 80
};                                                                                                                  // 81
                                                                                                                    // 82
Publication.prototype._publishChildrenOf = function(doc) {                                                          // 83
    _.each(this.childrenOptions, function(options) {                                                                // 84
        var pub = new Publication(this.subscription, options, [ doc ].concat(this.args));                           // 85
        this.publishedDocs.addChildPub(doc._id, pub);                                                               // 86
        pub.publish();                                                                                              // 87
    }, this);                                                                                                       // 88
};                                                                                                                  // 89
                                                                                                                    // 90
Publication.prototype._republishChildrenOf = function(doc) {                                                        // 91
    this.publishedDocs.eachChildPub(doc._id, function(publication) {                                                // 92
        publication.args[0] = doc;                                                                                  // 93
        publication._republish();                                                                                   // 94
    });                                                                                                             // 95
};                                                                                                                  // 96
                                                                                                                    // 97
Publication.prototype._unpublishAllDocuments = function() {                                                         // 98
    var collectionName = this._getCollectionName();                                                                 // 99
                                                                                                                    // 100
    this.publishedDocs.eachDocument(function(docId) {                                                               // 101
        this._removeDoc(collectionName, docId);                                                                     // 102
    }, this);                                                                                                       // 103
};                                                                                                                  // 104
                                                                                                                    // 105
Publication.prototype._getPublishedIds = function() {                                                               // 106
    if (this.cursor) {                                                                                              // 107
        this.cursor.rewind();                                                                                       // 108
        return this.cursor.map(function(doc) { return doc._id; });                                                  // 109
    } else {                                                                                                        // 110
        return [];                                                                                                  // 111
    }                                                                                                               // 112
};                                                                                                                  // 113
                                                                                                                    // 114
Publication.prototype._stopObservingCursor = function() {                                                           // 115
    if (this.observeHandle) {                                                                                       // 116
        this.observeHandle.stop();                                                                                  // 117
        delete this.observeHandle;                                                                                  // 118
    }                                                                                                               // 119
                                                                                                                    // 120
    if (this.observeChangesHandle) {                                                                                // 121
        this.observeChangesHandle.stop();                                                                           // 122
        delete this.observeChangesHandle;                                                                           // 123
    }                                                                                                               // 124
};                                                                                                                  // 125
                                                                                                                    // 126
Publication.prototype._removeDoc = function(collectionName, docId) {                                                // 127
    this.subscription.removed(collectionName, docId);                                                               // 128
    this._unpublishChildrenOf(docId);                                                                               // 129
    this.publishedDocs.remove(docId);                                                                               // 130
};                                                                                                                  // 131
                                                                                                                    // 132
Publication.prototype._unpublishChildrenOf = function(docId) {                                                      // 133
    debugLog("Publication._unpublishChildrenOf", "unpublishing children of " + this._getCollectionName() + ":" + docId);
                                                                                                                    // 135
    this.publishedDocs.eachChildPub(docId, function(publication) {                                                  // 136
        publication.unpublish();                                                                                    // 137
    });                                                                                                             // 138
};                                                                                                                  // 139
                                                                                                                    // 140
                                                                                                                    // 141
var PublishedDocumentList = function() {                                                                            // 142
    this.documents = [];                                                                                            // 143
};                                                                                                                  // 144
                                                                                                                    // 145
PublishedDocumentList.prototype.add = function(docId) {                                                             // 146
    var key = docId.valueOf();                                                                                      // 147
                                                                                                                    // 148
    if (!this.documents[key]) {                                                                                     // 149
        this.documents[key] = new PublishedDocument(docId);                                                         // 150
    }                                                                                                               // 151
};                                                                                                                  // 152
                                                                                                                    // 153
PublishedDocumentList.prototype.addChildPub = function(docId, publication) {                                        // 154
    var key = docId.valueOf();                                                                                      // 155
                                                                                                                    // 156
    this.add(docId);                                                                                                // 157
                                                                                                                    // 158
    if (publication) {                                                                                              // 159
        this.documents[key].addChildPub(publication);                                                               // 160
    }                                                                                                               // 161
};                                                                                                                  // 162
                                                                                                                    // 163
PublishedDocumentList.prototype.get = function(docId) {                                                             // 164
    var key = docId.valueOf();                                                                                      // 165
    return this.documents[key];                                                                                     // 166
};                                                                                                                  // 167
                                                                                                                    // 168
PublishedDocumentList.prototype.remove = function(docId) {                                                          // 169
    var key = docId.valueOf();                                                                                      // 170
    delete this.documents[key];                                                                                     // 171
};                                                                                                                  // 172
                                                                                                                    // 173
PublishedDocumentList.prototype.has = function(docId) {                                                             // 174
    return !!this.get(docId);                                                                                       // 175
};                                                                                                                  // 176
                                                                                                                    // 177
PublishedDocumentList.prototype.eachDocument = function(callback, context) {                                        // 178
    for (var key in this.documents) {                                                                               // 179
        if (this.documents.hasOwnProperty(key)) {                                                                   // 180
            callback.call(context || this, this.documents[key].docId);                                              // 181
        }                                                                                                           // 182
    }                                                                                                               // 183
};                                                                                                                  // 184
                                                                                                                    // 185
PublishedDocumentList.prototype.eachChildPub = function(docId, callback) {                                          // 186
    var doc = this.get(docId);                                                                                      // 187
                                                                                                                    // 188
    if (doc) {                                                                                                      // 189
        doc.eachChildPub(callback);                                                                                 // 190
    }                                                                                                               // 191
};                                                                                                                  // 192
                                                                                                                    // 193
PublishedDocumentList.prototype.getIds = function() {                                                               // 194
    var docIds = [];                                                                                                // 195
                                                                                                                    // 196
    this.eachDocument(function(docId) {                                                                             // 197
        docIds.push(docId);                                                                                         // 198
    });                                                                                                             // 199
                                                                                                                    // 200
    return docIds;                                                                                                  // 201
};                                                                                                                  // 202
                                                                                                                    // 203
                                                                                                                    // 204
var PublishedDocument = function(docId) {                                                                           // 205
    this.docId = docId;                                                                                             // 206
    this.childPublications = [];                                                                                    // 207
};                                                                                                                  // 208
                                                                                                                    // 209
PublishedDocument.prototype.addChildPub = function(childPublication) {                                              // 210
    this.childPublications.push(childPublication);                                                                  // 211
};                                                                                                                  // 212
                                                                                                                    // 213
PublishedDocument.prototype.eachChildPub = function(callback) {                                                     // 214
    for (var i = 0; i < this.childPublications.length; i++) {                                                       // 215
        callback(this.childPublications[i]);                                                                        // 216
    }                                                                                                               // 217
};                                                                                                                  // 218
                                                                                                                    // 219
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/reywood:publish-composite/lib/subscription.js                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Subscription = function(meteorSub) {                                                                                // 1
    var self = this;                                                                                                // 2
    this.meteorSub = meteorSub;                                                                                     // 3
    this.docHash = {};                                                                                              // 4
    this.refCounter = new DocumentRefCounter({                                                                      // 5
        onChange: function(collectionName, docId, refCount) {                                                       // 6
            debugLog("Subscription.refCounter.onChange", collectionName + ":" + docId.valueOf() + " " + refCount);  // 7
            if (refCount <= 0) {                                                                                    // 8
                meteorSub.removed(collectionName, docId);                                                           // 9
                self._removeDocHash(collectionName, docId);                                                         // 10
            }                                                                                                       // 11
        }                                                                                                           // 12
    });                                                                                                             // 13
};                                                                                                                  // 14
                                                                                                                    // 15
Subscription.prototype.added = function(collectionName, doc) {                                                      // 16
    this.refCounter.increment(collectionName, doc._id);                                                             // 17
                                                                                                                    // 18
    if (this._hasDocChanged(collectionName, doc._id, doc)) {                                                        // 19
        debugLog("Subscription.added", collectionName + ":" + doc._id);                                             // 20
        this.meteorSub.added(collectionName, doc._id, doc);                                                         // 21
        this._addDocHash(collectionName, doc);                                                                      // 22
    }                                                                                                               // 23
};                                                                                                                  // 24
                                                                                                                    // 25
Subscription.prototype.changed = function(collectionName, id, changes) {                                            // 26
    if (this._shouldSendChanges(collectionName, id, changes)) {                                                     // 27
        debugLog("Subscription.changed", collectionName + ":" + id);                                                // 28
        this.meteorSub.changed(collectionName, id, changes);                                                        // 29
        this._updateDocHash(collectionName, id, changes);                                                           // 30
    }                                                                                                               // 31
};                                                                                                                  // 32
                                                                                                                    // 33
Subscription.prototype.removed = function(collectionName, id) {                                                     // 34
    debugLog("Subscription.removed", collectionName + ":" + id.valueOf());                                          // 35
    this.refCounter.decrement(collectionName, id);                                                                  // 36
};                                                                                                                  // 37
                                                                                                                    // 38
Subscription.prototype._addDocHash = function(collectionName, doc) {                                                // 39
    this.docHash[this._buildHashKey(collectionName, doc._id)] = doc;                                                // 40
};                                                                                                                  // 41
                                                                                                                    // 42
Subscription.prototype._updateDocHash = function(collectionName, id, changes) {                                     // 43
    var key = this._buildHashKey(collectionName, id);                                                               // 44
    var existingDoc = this.docHash[key] || {};                                                                      // 45
    this.docHash[key] = _.extend(existingDoc, changes);                                                             // 46
};                                                                                                                  // 47
                                                                                                                    // 48
Subscription.prototype._shouldSendChanges = function(collectionName, id, changes) {                                 // 49
    return this._isDocPublished(collectionName, id) &&                                                              // 50
        this._hasDocChanged(collectionName, id, changes);                                                           // 51
};                                                                                                                  // 52
                                                                                                                    // 53
Subscription.prototype._isDocPublished = function(collectionName, id) {                                             // 54
    var key = this._buildHashKey(collectionName, id);                                                               // 55
    return !!this.docHash[key];                                                                                     // 56
};                                                                                                                  // 57
                                                                                                                    // 58
Subscription.prototype._hasDocChanged = function(collectionName, id, doc) {                                         // 59
    var existingDoc = this.docHash[this._buildHashKey(collectionName, id)];                                         // 60
                                                                                                                    // 61
    if (!existingDoc) { return true; }                                                                              // 62
                                                                                                                    // 63
    for (var i in doc) {                                                                                            // 64
        if (doc.hasOwnProperty(i) && !_.isEqual(doc[i], existingDoc[i])) {                                          // 65
            return true;                                                                                            // 66
        }                                                                                                           // 67
    }                                                                                                               // 68
                                                                                                                    // 69
    return false;                                                                                                   // 70
};                                                                                                                  // 71
                                                                                                                    // 72
Subscription.prototype._removeDocHash = function(collectionName, id) {                                              // 73
    var key = this._buildHashKey(collectionName, id);                                                               // 74
    delete this.docHash[key];                                                                                       // 75
};                                                                                                                  // 76
                                                                                                                    // 77
Subscription.prototype._buildHashKey = function(collectionName, id) {                                               // 78
    return collectionName + "::" + id.valueOf();                                                                    // 79
};                                                                                                                  // 80
                                                                                                                    // 81
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/reywood:publish-composite/lib/publish_composite.js                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.publishComposite = function(name, options) {                                                                 // 1
    return Meteor.publish(name, function() {                                                                        // 2
        var subscription = new Subscription(this),                                                                  // 3
            instanceOptions = options,                                                                              // 4
            args = Array.prototype.slice.apply(arguments);                                                          // 5
                                                                                                                    // 6
        if (typeof instanceOptions === "function") {                                                                // 7
            instanceOptions = instanceOptions.apply(this, args);                                                    // 8
        }                                                                                                           // 9
                                                                                                                    // 10
        var pub = new Publication(subscription, instanceOptions);                                                   // 11
        pub.publish();                                                                                              // 12
                                                                                                                    // 13
        this.onStop(function() {                                                                                    // 14
            pub.unpublish();                                                                                        // 15
        });                                                                                                         // 16
                                                                                                                    // 17
        this.ready();                                                                                               // 18
    });                                                                                                             // 19
};                                                                                                                  // 20
                                                                                                                    // 21
debugLog = function() { };                                                                                          // 22
                                                                                                                    // 23
Meteor.publishComposite.enableDebugLogging = function() {                                                           // 24
    debugLog = function(source, message) {                                                                          // 25
        while (source.length < 35) { source += " "; }                                                               // 26
        console.log("[" + source + "] " + message);                                                                 // 27
    };                                                                                                              // 28
};                                                                                                                  // 29
                                                                                                                    // 30
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reywood:publish-composite'] = {};

})();

//# sourceMappingURL=reywood_publish-composite.js.map
