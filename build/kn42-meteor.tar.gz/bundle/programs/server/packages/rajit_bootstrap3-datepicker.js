(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rajit:bootstrap3-datepicker'] = {};

})();

//# sourceMappingURL=rajit_bootstrap3-datepicker.js.map
