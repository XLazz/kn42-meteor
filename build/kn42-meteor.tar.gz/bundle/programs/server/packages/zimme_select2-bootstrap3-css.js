(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zimme:select2-bootstrap3-css'] = {};

})();

//# sourceMappingURL=zimme_select2-bootstrap3-css.js.map
