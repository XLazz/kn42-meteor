(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['grigio:overlay'] = {};

})();

//# sourceMappingURL=grigio_overlay.js.map
