(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Request;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/request/request-server.js                                //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Request = Meteor.wrapAsync(Npm.require('request'));                  // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.request = {
  Request: Request
};

})();

//# sourceMappingURL=request.js.map
