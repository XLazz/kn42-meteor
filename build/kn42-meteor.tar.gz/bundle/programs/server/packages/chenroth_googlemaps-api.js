(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;

/* Package-scope variables */
var GoogleMaps;

(function () {

//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// packages/chenroth:googlemaps-api/google-maps-server.js                       //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
                                                                                //
GoogleMaps = Npm.require("chenroth-googlemaps");                                // 1
                                                                                // 2
/*                                                                              // 3
// Configure Settings like this                                                 // 4
GoogleMaps.config({                                                             // 5
  'google-private-key': null,                                                   // 6
  'google-client-id': null,                                                     // 7
  'stagger-time': 200,                                                          // 8
  'encode-polylines': true,                                                     // 9
  'secure': false,                                                              // 10
  'proxy': null,                                                                // 11
});                                                                             // 12
*/                                                                              // 13
                                                                                // 14
                                                                                // 15
/**                                                                             // 16
 * Get Distance / Duration from Google Maps API                                 // 17
 *   (simple version, only supports from and to)                                // 18
 *                                                                              // 19
 * https://github.com/moshen/node-googlemaps/blob/master/lib/googlemaps.js#L136 // 20
 * https://developers.google.com/maps/documentation/distancematrix/             // 21
 *                                                                              // 22
 * @param mixed from - "from address"                                           // 23
 * @param string to - "to address"                                              // 24
 * @return object durationAndDistance                                           // 25
 */                                                                             // 26
GoogleMaps.getDistance = function(from, to) {                                   // 27
  var pattern = /[a-zA-Z]/;                                                     // 28
  var api = Meteor.wrapAsync(GoogleMaps.distance.bind(GoogleMaps), GoogleMaps); // 29
  var data = api(from, to);                                                     // 30
  var sdata = data.rows[0].elements[0];                                         // 31
  return {                                                                      // 32
    duration : sdata.duration.value,                                            // 33
    duration_nice : sdata.duration.text,                                        // 34
    distance : sdata.distance.value,                                            // 35
    distance_nice : sdata.distance.text                                         // 36
  };                                                                            // 37
};                                                                              // 38
                                                                                // 39
                                                                                // 40
/**                                                                             // 41
 * Get Directions / Route information from Google Maps API                      // 42
 *   (simple version, only supports from and to)                                // 43
 *                                                                              // 44
 * https://github.com/moshen/node-googlemaps/blob/master/lib/googlemaps.js#L151 // 45
 * https://developers.google.com/maps/documentation/directions/                 // 46
 *                                                                              // 47
 * @param mixed from - "from address"                                           // 48
 * @param string to - "to address"                                              // 49
 * @return object directions                                                    // 50
 */                                                                             // 51
GoogleMaps.getDirections = function(from, to) {                                 // 52
  var pattern = /[a-zA-Z]/;                                                     // 53
  var api = Meteor.wrapAsync(GoogleMaps.directions.bind(GoogleMaps));           // 54
  var data = api(from, to);                                                     // 55
  return data;                                                                  // 56
};                                                                              // 57
                                                                                // 58
/**                                                                             // 59
 * Get Directions / Route information from Google Maps API                      // 60
 *   (full version, supports all arguments)                                     // 61
 *                                                                              // 62
 * https://github.com/moshen/node-googlemaps/blob/master/lib/googlemaps.js#L151 // 63
 * https://developers.google.com/maps/documentation/directions/                 // 64
 *                                                                              // 65
 * @param object options (see defaults and docs for)                            // 66
 * @return object directions                                                    // 67
 *                                                                              // 68
 *                                                                              // 69
 * NOT WORKING RIGHT NOW... :/                                                  // 70
 */                                                                             // 71
GoogleMaps.getDirectionsFull = function(options) {                              // 72
  options = {                                                                   // 73
    origin: null,                                                               // 74
    destination: null,                                                          // 75
    callback: null,                                                             // 76
    sensor: 'false',                                                            // 77
    mode: null,                                                                 // 78
    waypoints: null,                                                            // 79
    alternatives: null,                                                         // 80
    avoid: null,                                                                // 81
    units: null,                                                                // 82
    language: null,                                                             // 83
    departureTime: null,                                                        // 84
    arrivalTime: null,                                                          // 85
    region: null                                                                // 86
  };                                                                            // 87
                                                                                // 88
  if (typeof from == "object") {                                                // 89
    options = _.extend(options, options);                                       // 90
  }                                                                             // 91
                                                                                // 92
  /*                                                                            // 93
   * tried this too, but didn't work for me                                     // 94
  var future = new Future;                                                      // 95
  options.callback = Meteor.bindEnvironment(function(error, body) {             // 96
     if (error) {                                                               // 97
       return future.error(error);                                              // 98
     }                                                                          // 99
     future.return(body);                                                       // 100
  });                                                                           // 101
  */                                                                            // 102
                                                                                // 103
  var api = Meteor.wrapAsync(GoogleMaps.directions.bind(GoogleMaps));           // 104
  var data = api(                                                               // 105
    options.origin,                                                             // 106
    options.destination,                                                        // 107
    options.callback,                                                           // 108
    options.sensor,                                                             // 109
    options.mode,                                                               // 110
    options.waypoints,                                                          // 111
    options.alternatives,                                                       // 112
    options.avoid,                                                              // 113
    options.units,                                                              // 114
    options.language,                                                           // 115
    options.departureTime,                                                      // 116
    options.arrivalTime,                                                        // 117
    options.region                                                              // 118
  );                                                                            // 119
  //console.log(data);                                                          // 120
  //var data = future.wait();                                                   // 121
  console.log(data);                                                            // 122
  return data;                                                                  // 123
};                                                                              // 124
                                                                                // 125
                                                                                // 126
                                                                                // 127
                                                                                // 128
                                                                                // 129
//////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['chenroth:googlemaps-api'] = {
  GoogleMaps: GoogleMaps
};

})();

//# sourceMappingURL=chenroth_googlemaps-api.js.map
