(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['peppelg:bootstrap-3-modal'] = {};

})();

//# sourceMappingURL=peppelg_bootstrap-3-modal.js.map
