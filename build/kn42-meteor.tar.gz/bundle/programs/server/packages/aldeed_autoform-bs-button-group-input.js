(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var HTML = Package.htmljs.HTML;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['aldeed:autoform-bs-button-group-input'] = {};

})();

//# sourceMappingURL=aldeed_autoform-bs-button-group-input.js.map
