(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var OAuth = Package.oauth.OAuth;
var Oauth = Package.oauth.Oauth;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/ipstas:connect-with/server.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/////////////////////////////                                                                                     // 1
// OAuth related functions //                                                                                     // 2
/////////////////////////////                                                                                     // 3
                                                                                                                  // 4
var OAuthEncryption = Package["oauth-encryption"] && Package["oauth-encryption"].OAuthEncryption;                 // 5
                                                                                                                  // 6
var pinEncryptedFieldsToUser = function (serviceData, userId) {                                                   // 7
	_.each(_.keys(serviceData), function (key) {                                                                     // 8
		var value = serviceData[key];                                                                                   // 9
		if (OAuthEncryption && OAuthEncryption.isSealed(value)) {                                                       // 10
			value = OAuthEncryption.seal(OAuthEncryption.open(value), userId);                                             // 11
		}                                                                                                               // 12
		serviceData[key] = value;                                                                                       // 13
	});                                                                                                              // 14
};                                                                                                                // 15
                                                                                                                  // 16
var addOauthService = function (user, options) {                                                                  // 17
	check(options.oauth, {                                                                                           // 18
		credentialToken: String,                                                                                        // 19
		// When an error occurs while retrieving the access token, we store                                             // 20
		// the error in the pending credentials table, with a secret of                                                 // 21
		// null. The client can call the login method with a secret of null                                             // 22
		// to retrieve the error.                                                                                       // 23
		credentialSecret: Match.OneOf(null, String)                                                                     // 24
	});                                                                                                              // 25
	// Retrieve the pending credential object                                                                        // 26
	var result = OAuth.retrieveCredential(options.oauth.credentialToken, options.oauth.credentialSecret);            // 27
	if (!result) {                                                                                                   // 28
		// OAuth credentialToken is not recognized, which could be either                                               // 29
		// because the popup was closed by the user before completion, or                                               // 30
		// some sort of error where the oauth provider didn't talk to our                                               // 31
		// server correctly and closed the popup somehow.                                                               // 32
		throw new Meteor.Error("No matching login attempt found");                                                      // 33
	}                                                                                                                // 34
	if (result instanceof Error) {                                                                                   // 35
		// We tried to login, but there was a fatal error. Report it back                                               // 36
		// to the user.                                                                                                 // 37
		throw result;                                                                                                   // 38
	}                                                                                                                // 39
	var serviceName = result.serviceName;                                                                            // 40
	var serviceData = result.serviceData;                                                                            // 41
	// Only allow external (oauth) services                                                                          // 42
	if (serviceName === "password" || serviceName === "resume") {                                                    // 43
		throw new Meteor.Error("Can't use updateOrCreateUserFromExternalService with internal service " + serviceName); // 44
	}                                                                                                                // 45
	// The user must not have used the service already                                                               // 46
	if (user.services[serviceName]) {                                                                                // 47
		throw new Meteor.Error(serviceName + " already used");                                                          // 48
	}                                                                                                                // 49
	// The service must provide an `id` field                                                                        // 50
	if (!_.has(serviceData, "id")) {                                                                                 // 51
		throw new Meteor.Error("Service data for service " + serviceName + " must include id");                         // 52
	}                                                                                                                // 53
	// If a user with this service user-id already exists, throw an error                                            // 54
	// XXX We can consider instead merging the two accounts                                                          // 55
	var selector = {};                                                                                               // 56
	var selectorKey = "services." + serviceName + ".id";                                                             // 57
	selector[selectorKey] = serviceData.id;                                                                          // 58
	if (Meteor.users.findOne(selector)) {                                                                            // 59
		throw new Meteor.Error("User already exists");                                                                  // 60
	}                                                                                                                // 61
                                                                                                                  // 62
	pinEncryptedFieldsToUser(serviceData, user._id);                                                                 // 63
	                                                                                                                 // 64
	// Add the service to the user object                                                                            // 65
	var modifier = {                                                                                                 // 66
		$set: {}                                                                                                        // 67
	};                                                                                                               // 68
	var serviceKey = "services." + serviceName;                                                                      // 69
	modifier.$set[serviceKey] = serviceData;                                                                         // 70
	Meteor.users.update(user._id, modifier);                                                                         // 71
	                                                                                                                 // 72
	// add service to profile                                                                                        // 73
	var modifier = {                                                                                                 // 74
		$set: {}                                                                                                        // 75
	};                                                                                                               // 76
	var serviceKey = "profile." + serviceName;                                                                       // 77
	modifier.$set[serviceKey] = 1;                                                                                   // 78
	console.log('user update modifier', modifier);                                                                   // 79
	Meteor.users.update(user._id, modifier);                                                                         // 80
};                                                                                                                // 81
                                                                                                                  // 82
                                                                                                                  // 83
                                                                                                                  // 84
////////////////////////////////                                                                                  // 85
// Password related functions //                                                                                  // 86
////////////////////////////////                                                                                  // 87
                                                                                                                  // 88
var addPasswordService = function (user, options) {                                                               // 89
	// TODO wait for https://github.com/meteor/meteor/pull/2271 to resolve                                           // 90
};                                                                                                                // 91
                                                                                                                  // 92
                                                                                                                  // 93
                                                                                                                  // 94
//////////////////////////////                                                                                    // 95
// `addLoginService` method //                                                                                    // 96
//////////////////////////////                                                                                    // 97
                                                                                                                  // 98
Meteor.methods({                                                                                                  // 99
	addLoginService: function (options) {                                                                            // 100
		var user = Meteor.user();                                                                                       // 101
		// Ensure the user is logged in                                                                                 // 102
		if (!user) {                                                                                                    // 103
			throw new Meteor.Error("Login required");                                                                      // 104
		}                                                                                                               // 105
		// Check arguments                                                                                              // 106
		try {                                                                                                           // 107
			// Wrapping this in a try/catch block to avoid throwing                                                        // 108
			// a Match.Error, which gets logged on the server console,                                                     // 109
			// while a Meteor.Error doesn't                                                                                // 110
			check(options, Object);                                                                                        // 111
		} catch (e) {                                                                                                   // 112
			throw new Meteor.Error("Match failed");                                                                        // 113
		}                                                                                                               // 114
		// Adding an oauth service                                                                                      // 115
		if (options.oauth) {                                                                                            // 116
			return addOauthService(user, options);                                                                         // 117
		}                                                                                                               // 118
		// Adding the password service                                                                                  // 119
		if (options.password) {                                                                                         // 120
			return addPasswordService(user, options);                                                                      // 121
		}                                                                                                               // 122
		throw new Meteor.Error("Bad request");                                                                          // 123
	},                                                                                                               // 124
	listLoginServices: function () {                                                                                 // 125
		var user = Meteor.user();                                                                                       // 126
		// Ensure the user is logged in                                                                                 // 127
		if (!user) {                                                                                                    // 128
			throw new Meteor.Error("Login required");                                                                      // 129
		}                                                                                                               // 130
		return _                                                                                                        // 131
			.chain(user.services)                                                                                          // 132
			.keys()                                                                                                        // 133
			.without("resume", "email")                                                                                    // 134
			.value();                                                                                                      // 135
	}                                                                                                                // 136
});                                                                                                               // 137
                                                                                                                  // 138
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ipstas:connect-with'] = {};

})();

//# sourceMappingURL=ipstas_connect-with.js.map
