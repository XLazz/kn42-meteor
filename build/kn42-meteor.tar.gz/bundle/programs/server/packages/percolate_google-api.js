(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var HTTP = Package.http.HTTP;
var DDP = Package.ddp.DDP;
var DDPServer = Package.ddp.DDPServer;
var Google = Package.google.Google;
var Q = Package['mrt:q'].Q;
var Accounts = Package['accounts-base'].Accounts;
var _ = Package.underscore._;

/* Package-scope variables */
var GoogleApi, wrapAsync, httpVerbs;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// packages/percolate:google-api/utils.js                                                            //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
// wrap an async function for client + server.                                                       // 1
//                                                                                                   // 2
// 1. if callback is provided, simply provide the async version                                      // 3
//                                                                                                   // 4
// 2i. else on the server, run sync                                                                  // 5
// 2ii. else on the client, return a promise                                                         // 6
                                                                                                     // 7
var wrap = Meteor.wrapAsync || Meteor._wrapAsync;                                                    // 8
                                                                                                     // 9
wrapAsync = function(fn) {                                                                           // 10
  return function(/* arguments */) {                                                                 // 11
    var args = _.toArray(arguments);                                                                 // 12
    if (_.isFunction(args[args.length - 1])) {                                                       // 13
      return fn.apply(this, args);                                                                   // 14
    } else {                                                                                         // 15
      if (Meteor.isClient) {                                                                         // 16
        return Q.nfapply(_.bind(fn, this), args);                                                    // 17
      } else {                                                                                       // 18
        return wrap(fn).apply(this, args);                                                           // 19
      }                                                                                              // 20
    }                                                                                                // 21
  }                                                                                                  // 22
}                                                                                                    // 23
                                                                                                     // 24
///////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// packages/percolate:google-api/google-api-async.js                                                 //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
// kill logs                                                                                         // 1
var Log = function () {}                                                                             // 2
                                                                                                     // 3
GoogleApi = {                                                                                        // 4
  // host component, shouldn't change                                                                // 5
  _host: 'https://www.googleapis.com',                                                               // 6
                                                                                                     // 7
  _callAndRefresh: function(method, path, options, callback) {                                       // 8
    var self = this;                                                                                 // 9
    options = options || {};                                                                         // 10
                                                                                                     // 11
    self._call(method, path, options,                                                                // 12
      // need to bind the env here so we can do mongo writes in the callback                         // 13
      // (when refreshing), if we call this on the server                                            // 14
      Meteor.bindEnvironment(function(error, result) {                                               // 15
        if (error && error.response && error.response.statusCode == 401) {                           // 16
          Log('google-api attempting token refresh');                                                // 17
                                                                                                     // 18
          return self._refresh(options.user, function(error) {                                       // 19
            if (error)                                                                               // 20
              return callback(error);                                                                // 21
                                                                                                     // 22
            // if we have the user, we'll need to re-fetch them, as their                            // 23
            // access token will have changed.                                                       // 24
            if (options.user)                                                                        // 25
              options.user = Meteor.users.findOne(options.user._id);                                 // 26
                                                                                                     // 27
            self._call(method, path, options, callback);                                             // 28
          });                                                                                        // 29
        } else {                                                                                     // 30
          callback(error, result);                                                                   // 31
        }                                                                                            // 32
    }, 'Google Api callAndRefresh'));                                                                // 33
  },                                                                                                 // 34
                                                                                                     // 35
  // call a GAPI Meteor.http function if the accessToken is good                                     // 36
  _call: function(method, path, options, callback) {                                                 // 37
    Log('GoogleApi._call, path:' + path);                                                            // 38
                                                                                                     // 39
    options = options || {};                                                                         // 40
    var user = options.user || Meteor.user();                                                        // 41
                                                                                                     // 42
    if (user && user.services && user.services.google &&                                             // 43
        user.services.google.accessToken) {                                                          // 44
      options.headers = options.headers || {};                                                       // 45
      options.headers.Authorization = 'Bearer ' + user.services.google.accessToken;                  // 46
                                                                                                     // 47
      HTTP.call(method, this._host + '/' + path, options, function(error, result) {                  // 48
        callback(error, result && result.data);                                                      // 49
      });                                                                                            // 50
    } else {                                                                                         // 51
      callback(new Meteor.Error(403, "Auth token not found." +                                       // 52
        "Connect your google account"));                                                             // 53
    }                                                                                                // 54
  },                                                                                                 // 55
                                                                                                     // 56
  _refresh: function(user, callback) {                                                               // 57
    Log('GoogleApi._refresh');                                                                       // 58
                                                                                                     // 59
    Meteor.call('exchangeRefreshToken', user && user._id, function(error, result) {                  // 60
      callback(error, result && result.access_token)                                                 // 61
    });                                                                                              // 62
  }                                                                                                  // 63
}                                                                                                    // 64
                                                                                                     // 65
// setup HTTP verbs                                                                                  // 66
httpVerbs = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'];                                               // 67
_.each(httpVerbs, function(verb) {                                                                   // 68
  GoogleApi[verb.toLowerCase()] = wrapAsync(function(path, options, callback) {                      // 69
    if (_.isFunction(options)) {                                                                     // 70
      callback = options;                                                                            // 71
      options = {};                                                                                  // 72
    }                                                                                                // 73
                                                                                                     // 74
    return this._callAndRefresh(verb, path, options, callback);                                      // 75
  })                                                                                                 // 76
});                                                                                                  // 77
                                                                                                     // 78
///////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// packages/percolate:google-api/google-api-methods.js                                               //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
Meteor.methods({                                                                                     // 1
  // Obtain a new access token using the refresh token                                               // 2
  exchangeRefreshToken: function(userId) {                                                           // 3
    this.unblock();                                                                                  // 4
                                                                                                     // 5
    var user;                                                                                        // 6
    if (userId && Meteor.isServer) {                                                                 // 7
      user = Meteor.users.findOne({_id: userId});                                                    // 8
    } else {                                                                                         // 9
      user = Meteor.user();                                                                          // 10
    }                                                                                                // 11
                                                                                                     // 12
    var config = Accounts.loginServiceConfiguration.findOne({service: "google"});                    // 13
    if (! config)                                                                                    // 14
      throw new Meteor.Error(500, "Google service not configured.");                                 // 15
                                                                                                     // 16
    if (! user.services || ! user.services.google || ! user.services.google.refreshToken)            // 17
      throw new Meteor.Error(500, "Refresh token not found.");                                       // 18
                                                                                                     // 19
    try {                                                                                            // 20
      var result = Meteor.http.call("POST",                                                          // 21
        "https://accounts.google.com/o/oauth2/token",                                                // 22
        {                                                                                            // 23
          params: {                                                                                  // 24
            'client_id': config.clientId,                                                            // 25
            'client_secret': config.secret,                                                          // 26
            'refresh_token': user.services.google.refreshToken,                                      // 27
            'grant_type': 'refresh_token'                                                            // 28
          }                                                                                          // 29
      });                                                                                            // 30
    } catch (e) {                                                                                    // 31
      var code = e.response ? e.response.statusCode : 500;                                           // 32
      throw new Meteor.Error(code, 'Unable to exchange google refresh token.', e.response)           // 33
    }                                                                                                // 34
                                                                                                     // 35
    if (result.statusCode === 200) {                                                                 // 36
      // console.log('success');                                                                     // 37
      // console.log(EJSON.stringify(result.data));                                                  // 38
                                                                                                     // 39
      Meteor.users.update(user._id, {                                                                // 40
        '$set': {                                                                                    // 41
          'services.google.accessToken': result.data.access_token,                                   // 42
          'services.google.expiresAt': (+new Date) + (1000 * result.data.expires_in),                // 43
        }                                                                                            // 44
      });                                                                                            // 45
                                                                                                     // 46
      return result.data;                                                                            // 47
    } else {                                                                                         // 48
      throw new Meteor.Error(result.statusCode, 'Unable to exchange google refresh token.', result); // 49
    }                                                                                                // 50
  }                                                                                                  // 51
});                                                                                                  // 52
///////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['percolate:google-api'] = {
  GoogleApi: GoogleApi
};

})();

//# sourceMappingURL=percolate_google-api.js.map
